Установка:
1. Скачать Calculator-0.0.1.tar.gz
2. pip install Calculator-0.0.1.tar.gz